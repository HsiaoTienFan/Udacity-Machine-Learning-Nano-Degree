The only file that needs to be run is the 'Capstone-Project.py' file. The 'visuals.py' and the 'data.csv' need to be in the same directory the main file is run from. 


The 'visuals.py' is a modified version of the one provided in the assignment for the finding donor project, which can be found at https://github.com/udacity/machine-learning/tree/master/projects/finding_donors

